/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Code-128 Barcode Generator for Medicine & Batch Labels
 * Produces crisp SVG vector barcodes for 58mm / 80mm thermal printers
 */

// Code 128 patterns (Subset B)
const CODE128_PATTERNS: { [key: number]: string } = {
  0: '212222', 1: '222122', 2: '222221', 3: '121223', 4: '121322', 5: '131222',
  6: '122213', 7: '122312', 8: '132212', 9: '221213', 10: '221312', 11: '231212',
  12: '112232', 13: '122132', 14: '122231', 15: '113222', 16: '123122', 17: '123221',
  18: '223211', 19: '221132', 20: '221231', 21: '213212', 22: '223112', 23: '312131',
  24: '311222', 25: '321122', 26: '321221', 27: '312212', 28: '322112', 29: '322211',
  30: '212123', 31: '212321', 32: '232121', 33: '111323', 34: '131123', 35: '131321',
  36: '112313', 37: '132113', 38: '132311', 39: '211313', 40: '231113', 41: '231311',
  42: '112133', 43: '112331', 44: '132131', 45: '113123', 46: '113321', 47: '133121',
  48: '313121', 49: '211331', 50: '231131', 51: '213113', 52: '213311', 53: '213131',
  54: '311123', 55: '311321', 56: '331121', 57: '312113', 58: '312311', 59: '332111',
  60: '314111', 61: '221411', 62: '431111', 63: '111224', 64: '111422', 65: '121124',
  66: '121421', 67: '141122', 68: '141221', 69: '112214', 70: '112412', 71: '122114',
  72: '122411', 73: '142112', 74: '142211', 75: '241211', 76: '221114', 77: '413111',
  78: '241112', 79: '134111', 80: '111242', 81: '121142', 82: '121241', 83: '114212',
  84: '124112', 85: '124211', 86: '411212', 87: '421112', 88: '421211', 89: '212141',
  90: '214121', 91: '412121', 92: '111143', 93: '111341', 94: '131141', 95: '114113',
  96: '114311', 97: '411113', 98: '411311', 99: '113141', 100: '114131', 101: '311141',
  102: '411131', 103: '211412', 104: '211214', 105: '211232', 106: '2331112'
};

const START_B = 104;
const STOP = 106;

export function encodeCode128B(text: string): string[] {
  const codes: number[] = [START_B];
  let checkSum = START_B;

  for (let i = 0; i < text.length; i++) {
    const code = text.charCodeAt(i) - 32;
    if (code >= 0 && code <= 95) {
      codes.push(code);
      checkSum += code * (i + 1);
    }
  }

  const checkDigit = checkSum % 103;
  codes.push(checkDigit);
  codes.push(STOP);

  const modules: string[] = [];
  for (const c of codes) {
    const pattern = CODE128_PATTERNS[c] || '212222';
    for (let p = 0; p < pattern.length; p++) {
      const width = parseInt(pattern[p], 10);
      const isBar = p % 2 === 0;
      for (let w = 0; w < width; w++) {
        modules.push(isBar ? '1' : '0');
      }
    }
  }

  return modules;
}

/**
 * Generates an SVG path for a Code-128 barcode
 */
export function generateBarcodeSvg(text: string, height: number = 44, barWidth: number = 1.6): { svgPath: string; totalWidth: number } {
  const safeText = text || '00000000';
  const modules = encodeCode128B(safeText);
  const totalWidth = modules.length * barWidth;

  let path = '';
  let inBar = false;
  let barStart = 0;

  for (let i = 0; i < modules.length; i++) {
    if (modules[i] === '1') {
      if (!inBar) {
        inBar = true;
        barStart = i * barWidth;
      }
    } else {
      if (inBar) {
        inBar = false;
        const width = (i * barWidth) - barStart;
        path += `M${barStart.toFixed(1)},0 h${width.toFixed(1)} v${height} h-${width.toFixed(1)} Z `;
      }
    }
  }

  if (inBar) {
    const width = (modules.length * barWidth) - barStart;
    path += `M${barStart.toFixed(1)},0 h${width.toFixed(1)} v${height} h-${width.toFixed(1)} Z `;
  }

  return { svgPath: path, totalWidth };
}
